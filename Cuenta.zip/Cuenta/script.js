// Elementos del DOM
const formularioRegistro = document.getElementById('formulario-registro');
const formularioLogin = document.getElementById('formulario-login');
const contenedorRegistro = document.getElementById('contenedor-registro');
const contenedorLogin = document.getElementById('contenedor-login');
const linkLogin = document.getElementById('link-login');
const linkRegistro = document.getElementById('link-registro');

// Campos de registro
const password = document.getElementById('contraseña');
const confirmarContraseña = document.getElementById('confirmarContraseña');
const seguridad = document.getElementById('nivelseguridad');

// Campos de login
const loginUsuario = document.getElementById('login-usuario');
const loginContraseña = document.getElementById('login-contraseña');

// Validacion de contraseña
password.addEventListener('input', () => {
  const valor = password.value;
  let fortaleza = 0;

  if (valor.length > 5) fortaleza += 30;
  if (valor.match(/[A-Z]/)) fortaleza += 30;
  if (valor.match(/[0-9]/)) fortaleza += 40;

  seguridad.style.width = fortaleza + '%';

  if (fortaleza < 40) seguridad.style.background = '#ef4444';
  else if (fortaleza < 70) seguridad.style.background = '#f59e0b';
  else seguridad.style.background = '#22c55e';
  
  // Validar coincidencia de contraseñas
  validarContraseñas();
});

confirmarContraseña.addEventListener('input', () => {
  validarContraseñas();
});

function validarContraseñas() {
  if (confirmarContraseña.value && password.value !== confirmarContraseña.value) {
    confirmarContraseña.setCustomValidity('Las contraseñas no coinciden');
  } else {
    confirmarContraseña.setCustomValidity('');
  }
}

// cambio con el formulario
linkLogin.addEventListener('click', (e) => {
  e.preventDefault();
  contenedorRegistro.style.display = 'none';
  contenedorLogin.style.display = 'block';
});

linkRegistro.addEventListener('click', (e) => {
  e.preventDefault();
  contenedorLogin.style.display = 'none';
  contenedorRegistro.style.display = 'block';
});
// envio del registro
formularioRegistro.addEventListener('submit', (e) => {
  e.preventDefault();

  if (formularioRegistro.checkValidity() && password.value === confirmarContraseña.value) {
    const nombreusuario = document.getElementById('nombreusuario').value;
    
    // Obtener usuarios existentes
    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    
    // Verificar si el usuario ya existe
    if (usuarios.some(u => u.nombreusuario === nombreusuario)) {
      alert('El usuario ya existe. Por favor, elige otro nombre.');
      return;
    }

    const datosUsuario = {
      nombreusuario: nombreusuario,
      email: document.getElementById('correoElectronico').value,
      password: password.value,
      fecha: new Date().toLocaleString()
    };

    // Agregar el nuevo usuario al array
    usuarios.push(datosUsuario);
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
    
    alert('Registro exitoso, Ahora puedes iniciar sesión.');
    console.log('Todos los usuarios:', usuarios);
    formularioRegistro.reset();
    seguridad.style.width = '0%';
    
    // Cambiar a formulario de login
    contenedorRegistro.style.display = 'none';
    contenedorLogin.style.display = 'block';
  } else {
    alert('Por favor, corrige los errores en el formulario.');
  }
});

// envio del login
formularioLogin.addEventListener('submit', (e) => {
  e.preventDefault();

  const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

  if (usuarios.length === 0) {
    alert('Registrate primero');
    return;
  }

  const usuarioIngresado = loginUsuario.value;
  const contraseñaIngresada = loginContraseña.value;

  // Buscar el usuario en el array
  const usuarioEncontrado = usuarios.find(
    u => u.nombreusuario === usuarioIngresado && u.password === contraseñaIngresada
  );

  if (usuarioEncontrado) {
    alert(`¡Bienvenido ${usuarioEncontrado.nombreusuario}! Sesión iniciada correctamente.`);
    console.log('Login exitoso:', usuarioEncontrado);
    formularioLogin.reset();
  } else {
    alert('Usuario o contraseña incorrectos.');
  }
});

